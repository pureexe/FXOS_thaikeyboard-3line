function fx_th2lne(){
	document.getElementById('area_lne').value=document.getElementById('area_thai').value.lne();
}
function fx_lne2th(){
	document.getElementById('area_thai').value=document.getElementById('area_lne').value.thai();
}
